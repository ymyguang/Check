import datetime
import re
import urllib.parse
from datetime import datetime as da
import time
from math import ceil
import ddddocr
import requests
from bs4 import BeautifulSoup
import properties,feedback,recall

# 1042333099 班级群
targetQQ = properties.targetQQ
qq_dict = properties.qq_dict
# 键：学号； 值：姓名
_map = dict()
maxPage = 99
dulDic = {
    '19L0751167': "1258128061",
    '19L0751197': "2363299276",
    "19L0751051": '2797403895',
    "19L0751147": "1149487811",
    "17L0802120": "1115234075",
    "19L0752173": "2248278179",
    "19L0751199": "1394668543",
    "19L0751074": "3165217896"
}

header = {
    'Upgrade-Insecure-Requests': '1',
    'DNT': '1',
    'Content-Type': 'application/x-www-form-urlencoded',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Referer': 'http://xscfw.hebust.edu.cn/evaluate/verifyCode?d=1636955535211',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7'
}


# 获取cookie和验证码
def tryLogin():
    r = requests.get('http://xscfw.hebust.edu.cn/evaluate/verifyCode', stream=True)
    cookie = str(r.headers['Set-Cookie']).split(" ")[0]
    header['Cookie'] = cookie

    ocr = ddddocr.DdddOcr()
    res = ocr.classification(r.content)
    print("cookie:{}    verify:{}".format(cookie, res))
    r = requests.post("http://xscfw.hebust.edu.cn/evaluate/evaluate", headers=header,
                      data="username=xxxyhaolei&password=Haolei2021l19.&verifyCode=" + urllib.parse.quote(res))


# 使cookie生效 (登陆)
def login():
    tryLogin()
    # 登陆失败，一直重复
    while not isOk():
        tryLogin()


def getUrl():
    url = "http://xscfw.hebust.edu.cn/evaluate/survey/surveyStuList?id="
    a = datetime.datetime(2021, 11, 12)
    b = datetime.datetime.now()
    cc = (b - a).days
    listName = 712 + cc
    url += str(listName)
    return url


def getId():
    now = da.now()
    current_time = now.strftime("%Y-%#m-%#d")
    current_time = "2022-3-22"

    c = requests.post("http://xscfw.hebust.edu.cn/evaluate/survey/surveyList", headers=header,
                      data="surveyCX=" + str(
                          current_time) + "%E5%81%A5%E5%BA%B7%E6%97%A5%E6%8A%A5&typeCX=-1&pageNo=1").text
    soup = BeautifulSoup(c, 'html.parser')
    # print(current_time)
    # print(soup)
    current_time += "健康日报"
    for tr in soup.findAll('tbody')[0].findAll('tr'):
        res = tr.a
        if current_time in res['title']:
            Lid = res['href']
            print(res['title'], "->", Lid)
            return 'http://xscfw.hebust.edu.cn/evaluate/survey/' + Lid


# 登陆成功后（cookie生效）获取原始信息
def getInfo(page):
    # 初始化参数
    global maxPage
    # 构造请求
    params = {
        "typeCX": 0,  # 未完成0，已完成1
        "pageNo": page,
        # "classCX": "软件L194"  # 班级号
    }
    c = requests.post(url=getId(), params=params, headers=header).text

    # 获取maxPage数据
    index = str(c).find("maxPage")
    if index == -1:  # 无信息
        print("全部填报完成")
        maxPage = 0
    else:

        maxPage = re.findall(r'var maxPage = (.*);', c)[0]
        # print(maxPage)
        # maxPage = 1
    return c


# 登陆验证
def isOk():
    params = {
        "typeCX": 0,  # 未完成0，已完成1
        "pageNo": 0,
        "classCX": "软件L194"  # 班级号
    }
    c = requests.post(url=getUrl(), params=params, headers=header).text
    # 检查cookie
    if str(c).find("重新") != -1 or str(c).find("正确的用户名") != -1:
        print("登陆失败")
        return False
    print("登陆成功")
    return True


# 处理信息
def process(index):
    target = getInfo(index)
    try:
        soup = BeautifulSoup(target, 'html.parser')
        if soup.tbody is None:
            return
        t = soup.tbody.get_text()
        tt = str(t).split("未完成")
        tt.pop()

        for i in tt:
            sin = i.split("\n")[-6]
            number = i.split("\n")[-7]
            # 维护学号信息
            _map[number] = sin
            # print(number,sin)
    except():
        pass


def getQQ(name, number):
    dulName = ['王鑫', '吕小龙', '张康', '刘金鹏']
    QQ = None
    # 重名，按照学号查询
    if name in dulName:
        QQ = dulDic[number]
    # 不重名用姓名查询
    elif name in qq_dict:
        QQ = qq_dict[name]

    if QQ is not None:
        return " @at={}@ \n".format(QQ)
    else:
        return "(找不到此人对应QQ号，无法艾特)\n"


def generateMess():
    pageNum = 30  # at的总个数
    f = 0
    if len(_map) == pageNum:
        return
    message = "以下同学抓紧时间填报体温！ \n"
    totalPage = str(ceil(len(_map) / pageNum))
    currentPage = 1
    recall.action()
    for index in range(len(_map)):
        f += 1  # 记录本次推送at的个数
        number = list(_map)[index]
        name = list(_map.values())[index]
        message += name + " " + number + "  "
        message += getQQ(name, number)
        if f % pageNum == 0:  # 满足一页的个数，就推送
            message += "\n【第{}页，共{}页】--共{}人\nhttp://xscfw.hebust.edu.cn/survey/index.action".format(str(currentPage),
                                                                                                    totalPage,
                                                                                                    len(_map))
            currentPage += 1
            feedback.feedback(message, "G", qq=targetQQ)
            message = '以下同学抓紧时间填报体温！ \n'
            time.sleep(6)  # 5秒内不能连续推送
    if f % pageNum != 0:  # 不是pageNum倍数的情况
        message += "\n【第{}页，共{}页】--共{}人\nhttp://xscfw.hebust.edu.cn/survey/index.action".format(str(currentPage),
                                                                                                totalPage,
                                                                                                len(_map))
        feedback.feedback(message, "G", qq=targetQQ)


if __name__ == '__main__':
    print("\n")
    print(da.now())
    print("------------------------------------------------")
    login()
    recall.action()
    for i in range(1, 100):
        print("################################################")
        process(i)
        print("第{}页，处理完成".format(i))
        if i == maxPage or maxPage == 0:
            break
    generateMess()
    print("------------------------------------------------")
    print("未填报同学{}个".format(len(_map)))
